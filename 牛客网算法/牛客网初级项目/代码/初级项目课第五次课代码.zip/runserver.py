# -*- encoding=UTF-8 -*-

from nowstagram import app

if __name__ == '__main__':
    app.run(debug=True)